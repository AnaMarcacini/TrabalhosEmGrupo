# TrabalhosEmGrupo
Ana Helena Marcacini RA: 20.01305-0 
Ettore Padula Dalben RA: 20.00387-0 
Pedro Henrique Hein RA: 20.00134-7
