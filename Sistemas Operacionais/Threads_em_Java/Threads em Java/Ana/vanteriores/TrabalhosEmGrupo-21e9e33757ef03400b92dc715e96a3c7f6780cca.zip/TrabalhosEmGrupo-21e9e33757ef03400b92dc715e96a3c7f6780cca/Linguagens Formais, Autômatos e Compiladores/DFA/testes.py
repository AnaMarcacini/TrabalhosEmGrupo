
#set cria um conjunto e nn uma lista
#x = set([1,2,3,4,52,32,234,2,2,23,42,])
x =[1,2,3,4]
x = set([1,2,3,4,1])
print(x)
    