package prodcon;

public class Account {
    private float balance; //saldo

    protected Cliente c1;
    protected Cliente c2;
    



}

//realizar um depósito ou uma retirada
//(jogue uma moeda antes de executar e escolha ...).


//O banco não aceita que retiradas sejam executadas quando a conta não possui saldo sufi- ciente (não se admite saldo negativo). Os clientes podem continuamente realizar depósitos ou retiradas e cabe ao seu programa sincronizar como isso será feito, de modo a manter a consistência e integridade da conta-corrente