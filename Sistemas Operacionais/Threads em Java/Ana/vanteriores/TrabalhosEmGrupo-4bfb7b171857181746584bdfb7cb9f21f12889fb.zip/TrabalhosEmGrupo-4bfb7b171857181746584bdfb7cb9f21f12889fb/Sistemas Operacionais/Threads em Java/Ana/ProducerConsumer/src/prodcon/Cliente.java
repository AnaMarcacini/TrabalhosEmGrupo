package prodcon;

public class Cliente {
    private String nome;
    private Account conta;


    public Cliente(String nome, Account conta) {
        this.nome = nome;
        this.conta = conta;
    }

    private int execute(){
        
    }



    
}
