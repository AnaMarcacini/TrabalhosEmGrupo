//Definição das variaveis globais
#define Tamanho_Lista 10;
void inicializarLista();


//percorrer lista e imprimir
//excluir da lista 
// add na lista

int main(){

    int next[Tamanho_Lista],key[Tamanho_Lista],prev[Tamanho_Lista],inicio, fim;//todo vetor é um ponteiro
    // next próximo elemento , key valor , prev elemento anterior, inicio posição do elemento inicial, fim posição do  elemento final


    return 0;
}

void inicializarLista(){
    
    
}