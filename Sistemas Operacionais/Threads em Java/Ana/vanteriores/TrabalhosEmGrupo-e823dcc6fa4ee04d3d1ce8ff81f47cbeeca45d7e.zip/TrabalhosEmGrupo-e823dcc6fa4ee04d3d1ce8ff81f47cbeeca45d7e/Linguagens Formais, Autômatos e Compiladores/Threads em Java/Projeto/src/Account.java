public class Account {
    private int balance; //saldo

//correntes

    public Account(int saldoInicial) {
        this.balance = saldoInicial;

        System.out.println("Conta criada com saldo inicial de: ", saldoInicial);
    }

    void deposit(){//deposito

    }

    void withdraw(){//retiradas

    }
}
