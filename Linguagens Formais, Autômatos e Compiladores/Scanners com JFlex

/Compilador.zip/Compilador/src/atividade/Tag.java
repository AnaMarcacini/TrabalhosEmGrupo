package atividade;

// Rótulos para as marcas
public enum Tag {
    EOF, NUMBER, ID,
    RELOP, IF, ELSE, WHILE, FOREACH, FUNCTION, END, PROGRAM,STR,
    LT, LE, EQ, NE, GT, GE,
    VR, PV, CE, CD, PE, PD,
    IG,
    ADD, SUB, MULT, DIV, RES, INCR, DECR,
    ABRE,FECHA
}